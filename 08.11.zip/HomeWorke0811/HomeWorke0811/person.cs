﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homeworke0811
{
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Specialization { get; set; }

        public string City { get; set; }

        public string Mood { get; set; }

        public int HaveNiceDay { get; set; }
        public Person(string name, int age, string specialization)
        {
            Name = name;
            Age = age;
            Specialization = specialization;
        }
    }
}
